const fileInput = document.getElementById("fileInput");
//RGB
const canvasOriginal = document.getElementById("original");
const canvasRed = document.getElementById("red");
const canvasBlue = document.getElementById("blue");
const canvasGreen = document.getElementById("green");
//HSV
const canvasHue = document.getElementById("hue");
const canvasSaturation = document.getElementById("saturation");
const canvasValue = document.getElementById("value");
const canvasHSV = document.getElementById("hsv");
const canvasHsv180a200 = document.getElementById("hsv180a200");
const canvasCambiado = document.getElementById("cambiado");

//---
//RGB
const ctxOriginal = canvasOriginal.getContext("2d");
const ctxRed = canvasRed.getContext("2d");
const ctxBlue = canvasBlue.getContext("2d");
const ctxGreen = canvasGreen.getContext("2d");

//HSV
const ctxHue = canvasHue.getContext("2d");
const ctxSaturation = canvasSaturation.getContext("2d");
const ctxValue = canvasValue.getContext("2d");
const ctxHSV = canvasHSV.getContext("2d");
const ctxHsv180a200 = canvasHsv180a200.getContext("2d");
const ctxCambiado = canvasCambiado.getContext("2d");

const MAX_WIDTH = 600;
const MAX_HEIGHT = 400;

fileInput.addEventListener("change", function () {

    const file = fileInput.files[0];

    if (!file) {
        return;
    }

    const image = new Image();

    image.onload = function () {


        let width = image.width;
        let height = image.height;

        const scale = Math.min(
            MAX_WIDTH / width,
            MAX_HEIGHT / height,
            1
        );

        width = Math.floor(width * scale);
        height = Math.floor(height * scale);



        const tempCanvas = document.createElement("canvas");

        tempCanvas.width = width;
        tempCanvas.height = height;

        const tempCtx = tempCanvas.getContext("2d");

        tempCtx.drawImage(
            image,
            0,
            0,
            width,
            height
        );



        canvasOriginal.width = width;
        canvasOriginal.height = height;

        canvasRed.width = width;
        canvasRed.height = height;

        canvasBlue.width = width;
        canvasBlue.height = height;
        
        canvasGreen.width = width;
        canvasGreen.height = height;
        
        canvasHue.width = width;
        canvasHue.height = height;

        canvasSaturation.width = width;
        canvasSaturation.height = height;
       
        canvasValue.width = width;
        canvasValue.height = height;

        canvasHSV.width = width;
        canvasHSV.height = height;

        canvasHsv180a200.width = width;
        canvasHsv180a200.height = height;

        canvasCambiado.width = width;
        canvasCambiado.height = height;

        ctxOriginal.drawImage(
            tempCanvas,
            0,
            0
        );

        const imageData = tempCtx.getImageData(
            0,
            0,
            width,
            height
        );

        const data = imageData.data;


        const redData = ctxRed.createImageData(
            width,
            height
        );

        const blueData = ctxBlue.createImageData(
            width,
            height
        );

        const greenData = ctxGreen.createImageData(
            width,
            height
        );

        //tamaños HSV
        const hueData = ctxHue.createImageData(
            width,
            height
        );
    
        const saturationData = ctxSaturation.createImageData(
            width,
            height
        );
        const valueData = ctxValue.createImageData(
            width,
            height
        );

        const hsvData = ctxHSV.createImageData(
            width,
            height
        );

        const hsv180a200Data = ctxHsv180a200.createImageData(
            width,
            height
        );
        const cambiadoData = ctxCambiado.createImageData(
            width,
            height
        );

        for (let y = 0; y < height; y++) {

            for (let x = 0; x < width; x++) {

                const index = (y * width + x) * 4;

                // Obtener RGB
                const R = data[index];
                const G = data[index + 1];
                const B = data[index + 2];

                // Canal rojo
                redData.data[index] = R;
                redData.data[index + 1] = 0;
                redData.data[index + 2] = 0;
                redData.data[index + 3] = 255;


                // Obtener RGB
                const RB = data[index];
                const GB = data[index + 1];
                const BB = data[index + 2];

                // Canal azul
                blueData.data[index] = 0;
                blueData.data[index + 1] = 0;
                blueData.data[index + 2] = B;
                blueData.data[index + 3] = 255;

                
                // Obtener RGB
                const RG = data[index];
                const GG = data[index + 1];
                const BG = data[index + 2];

                // Canal verde
                greenData.data[index] = 0;
                greenData.data[index + 1] = G;
                greenData.data[index + 2] = 0;
                greenData.data[index + 3] = 255;

 

                //Desde Aca es el rgb a hsv

                const rhsv = R / 255;
                const ghsv = G / 255;
                const bhsv = B / 255;

                const Cmax = Math.max(rhsv, ghsv, bhsv);
                const Cmin = Math.min(rhsv, ghsv, bhsv);
                const delta = Cmax - Cmin;

                //El H:
                let H = 0;

                if (delta === 0) {
                    H = 0;
                }

                else if (Cmax === rhsv) {
                    H = 60 * ((ghsv - bhsv) / delta);
                }

                else if (Cmax === ghsv) {
                    H = 60 * ((bhsv - rhsv) / delta) + 120;
                }

                else if (Cmax === bhsv) {
                    H = 60 * ((rhsv - ghsv) / delta) + 240;
                }

                if (H < 0) {
                    H = H + 360;
                }

                //EL S:
                let S = 0;

                if (Cmax === 0) {
                    S = 0;
                }
                else {
                    S = delta / Cmax;
                }

                //EL V:
                const V = Cmax;
 
                // despuesa pasamos a RGB.

                const hueRGB = H / 360 * 255;
                hueData.data[index] = hueRGB;
                hueData.data[index + 1] = hueRGB;
                hueData.data[index + 2] = hueRGB;
                hueData.data[index + 3] = 255;

                saturationData.data[index] = S*255;
                saturationData.data[index + 1] = S*255;
                saturationData.data[index + 2] = S*255;
                saturationData.data[index + 3] = 255;

                valueData.data[index] = V*255;
                valueData.data[index + 1] = V*255;
                valueData.data[index + 2] = V*255;
                valueData.data[index + 3] = 255;

                //HSV COMPLEto
                const C = V * S;

                const X = C * (
                    1 - Math.abs(
                        ((H / 60) % 2) - 1
                    )
                );

                const m = V - C;


                let rHSV = 0;
                let gHSV = 0;
                let bHSV = 0;


                if (H >= 0 && H < 60) {

                    rHSV = C;
                    gHSV = X;
                    bHSV = 0;

                }
                else if (H >= 60 && H < 120) {

                    rHSV = X;
                    gHSV = C;
                    bHSV = 0;

                }
                else if (H >= 120 && H < 180) {

                    rHSV = 0;
                    gHSV = C;
                    bHSV = X;

                }
                else if (H >= 180 && H < 240) {

                    rHSV = 0;
                    gHSV = X;
                    bHSV = C;

                }
                else if (H >= 240 && H < 300) {

                    rHSV = X;
                    gHSV = 0;
                    bHSV = C;

                }
                else {

                    rHSV = C;
                    gHSV = 0;
                    bHSV = X;

                }
                // Agregar m y convertir a 0-255

                const finalR = (rHSV + m) * 255;
                const finalG = (gHSV + m) * 255;
                const finalB = (bHSV + m) * 255;

                //HSV COMPLETA:

                hsvData.data[index] = finalR;
                hsvData.data[index + 1] = finalG;
                hsvData.data[index + 2] = finalB;
                hsvData.data[index + 3] = 255;

                //me toco de 180 a 200 asi que HSV
                // entendi de dos formas, las hago las dos jjsjsj 

                // Que el H entre 180 y 200 se pone con el color, si no queda negro (asi entendi :v)

                if (H >= 180 && H <= 200) {

                    hsv180a200Data.data[index] = finalR;
                    hsv180a200Data.data[index + 1] = finalG;
                    hsv180a200Data.data[index + 2] = finalB;
                    hsv180a200Data.data[index + 3] = 255;

                }
                else {

                    hsv180a200Data.data[index] = 0;
                    hsv180a200Data.data[index + 1] = 0;
                    hsv180a200Data.data[index + 2] = 0;
                    hsv180a200Data.data[index + 3] = 255;

                }

                // la otra que cambia los colores entre 180° y 200° a otro color

                if (H >= 180 && H <= 200) {

                    cambiadoData.data[index] = 0;       
                    cambiadoData.data[index + 1] = 255; 
                    cambiadoData.data[index + 2] = 0;   
                    cambiadoData.data[index + 3] = 255; 

                }


                else {
                    cambiadoData.data[index] = finalR;
                    cambiadoData.data[index + 1] = finalG;
                    cambiadoData.data[index + 2] = finalB;
                    cambiadoData.data[index + 3] = 255;

                }

            }
        }

        ctxRed.putImageData(
            redData,
            0,
            0
        );
        ctxBlue.putImageData(
            blueData,
            0,
            0
        );
        ctxGreen.putImageData(
            greenData,
            0,
            0
        );



        ctxHue.putImageData(
            hueData,
            0,
            0
        );

        ctxSaturation.putImageData(
            saturationData,
            0,
            0
        );
        ctxValue.putImageData(
            valueData,
            0,
            0
        );

        ctxHSV.putImageData(
            hsvData,
            0,
            0
        );

        ctxHsv180a200.putImageData(
            hsv180a200Data,
            0,
            0
        )
        ctxCambiado.putImageData(
            cambiadoData,
            0,
            0
        )
        

    };

    image.src = URL.createObjectURL(file);
});