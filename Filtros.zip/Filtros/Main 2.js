const fileInput = document.getElementById("fileInput");

const canvasOriginal = document.getElementById("original");
const canvasIdentidad = document.getElementById("identidad");
const canvasPromedio = document.getElementById("promedio");
const canvasSharpen = document.getElementById("sharpen");
const canvasBordes = document.getElementById("bordes");
const canvasGrises = document.getElementById("grises");
const canvasCincoXCinco = document.getElementById("cincoXcinco");
const canvasPrueba = document.getElementById("prueba");

const ctxOriginal = canvasOriginal.getContext("2d");
const ctxIdentidad = canvasIdentidad.getContext("2d");
const ctxPromedio = canvasPromedio.getContext("2d");
const ctxSharpen = canvasSharpen.getContext("2d");
const ctxBordes = canvasBordes.getContext("2d");
const ctxGrises = canvasGrises.getContext("2d");
const ctxCincoXCinco = canvasCincoXCinco.getContext("2d");
const ctxPrueba = canvasPrueba.getContext("2d");

const MAX_WIDTH = 500;
const MAX_HEIGHT = 400;

let imagen = new Image();

const kernels = {
    identidad: {
        matriz: [
            [0, 0, 0],
            [0, 1, 0],
            [0, 0, 0]
        ],
        divisor: 1
    },

    promedio: {
        matriz: [
            [1, 1, 1],
            [1, 1, 1],
            [1, 1, 1]
        ],
        divisor: 9
    },

    sharpen: {
        matriz: [
            [0, -1, 0],
            [-1, 5, -1],
            [0, -1, 0]
        ],
        divisor: 1
    },

    bordes: {
        matriz: [
            [-1, -1, -1],
            [-1, 8, -1],
            [-1, -1, -1]
        ],
        divisor: 1
    },

    grises: {
        matriz: [
            [1]
        ],
        divisor: 1,
        grayscale: true
    },

    cincoXcinco: {
        matriz: [
            [1, 1, 1, 1, 1],
            [1, 1, 1, 1, 1],
            [1, 1, 1, 1, 1],
            [1, 1, 1, 1, 1],
            [1, 1, 1, 1, 1]
        ],
        divisor: 25
    },

    // solo queria probar diferntes valores :)
    prueba: {
        matriz: [
            [0, 1, 0],
            [1, 4, 1],
            [0, 1,0]
        ],
        divisor: 1
    }
};



// carga de la imagen


fileInput.addEventListener("change", function() {
    const file = fileInput.files[0];

    if (!file) {
        return;
    }

    imagen.src = URL.createObjectURL(file);
});


// carga de la imagen y redimensionamiento


imagen.onload = function() {
    let width = imagen.width;
    let height = imagen.height;

    const escalaX = MAX_WIDTH / width;
    const escalaY = MAX_HEIGHT / height;
    const escala = Math.min(escalaX, escalaY, 1);

    width = Math.floor(width * escala);
    height = Math.floor(height * escala);

    canvasOriginal.width = width;
    canvasOriginal.height = height;

    canvasIdentidad.width = width;
    canvasIdentidad.height = height;

    canvasPromedio.width = width;
    canvasPromedio.height = height;

    canvasSharpen.width = width;
    canvasSharpen.height = height;

    canvasBordes.width = width;
    canvasBordes.height = height;
    
    canvasGrises.width = width;
    canvasGrises.height = height;

    canvasCincoXCinco.width = width;
    canvasCincoXCinco.height = height;

    canvasPrueba.width = width;
    canvasPrueba.height = height;

    ctxOriginal.drawImage(imagen, 0, 0, width, height);

    aplicarConvolucion(ctxIdentidad, kernels.identidad);
    aplicarConvolucion(ctxPromedio, kernels.promedio);
    aplicarConvolucion(ctxSharpen, kernels.sharpen);
    aplicarConvolucion(ctxBordes, kernels.bordes);
    aplicarConvolucion(ctxGrises, kernels.grises);
    aplicarConvolucion(ctxCincoXCinco, kernels.cincoXcinco);
    aplicarConvolucion(ctxPrueba, kernels.prueba);
};


// Connvolucion


function aplicarConvolucion(ctxSalida, kernel) {
    const width = canvasOriginal.width;
    const height = canvasOriginal.height;

    const imagenEntrada = ctxOriginal.getImageData(0, 0, width, height);
    const datosEntrada = imagenEntrada.data;

    const imagenResultado = ctxSalida.createImageData(width, height);
    const datosSalida = imagenResultado.data;

    const Kernel = kernel.matriz;
    const divisor = kernel.divisor;
    const isGrayscale = kernel.grayscale || false;

    const size = Kernel.length;
    const radio = Math.floor(size / 2);

    if (isGrayscale) {
        for (let i = 0; i < datosEntrada.length; i += 4) {

            const R = datosEntrada[i];
            const G = datosEntrada[i + 1];
            const B = datosEntrada[i + 2];

            const Y = clamp(0.299 * R + 0.587 * B + 0.114 * G);

            datosSalida[i] = Y;
            datosSalida[i + 1] = Y;
            datosSalida[i + 2] = Y;
            datosSalida[i + 3] = 255;
        }

        ctxSalida.putImageData(imagenResultado, 0, 0);
        return;
    }
    // algunas paginas que me ayudaron para hacer el grises:
    //https://parzibyte.me/blog/posts/javascript-imagen-blanco-negro-dithering-grises/
    // https://es.stackoverflow.com/questions/625775/convertir-imagen-jpg-a-color-en-imagen-en-escala-de-grises-en-javascript
    // y otras, pues no  son igules pero me ayudaron a entender :v

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {

            let sumaR = 0;
            let sumaG = 0;
            let sumaB = 0;

            for (let ky = -radio; ky <= radio; ky++) {
                for (let kx = -radio; kx <= radio; kx++) {

                    const pixelX = x + kx;
                    const pixelY = y + ky;

                    if (pixelX < 0 || pixelX >= width ||
                        pixelY < 0 || pixelY >= height) {
                        continue;
                    }

                    const K = Kernel[ky + radio][kx + radio];

                    const index = (pixelY * width + pixelX) * 4;

                    const R = datosEntrada[index];
                    const G = datosEntrada[index + 1];
                    const B = datosEntrada[index + 2];

                    sumaR += R * K;
                    sumaG += G * K;
                    sumaB += B * K;
                }
            }

            sumaR = sumaR / divisor;
            sumaG = sumaG / divisor;
            sumaB = sumaB / divisor;

            sumaR = clamp(sumaR);
            sumaG = clamp(sumaG);
            sumaB = clamp(sumaB);

            const indexSalida = (y * width + x) * 4;

            datosSalida[indexSalida] = sumaR;
            datosSalida[indexSalida + 1] = sumaG;
            datosSalida[indexSalida + 2] = sumaB;
            datosSalida[indexSalida + 3] = 255;
        }
    }
    

    ctxSalida.putImageData(imagenResultado, 0, 0);
}



// CLAMP


function clamp(valor) {
    return Math.max(0, Math.min(255, Math.round(valor)));
}