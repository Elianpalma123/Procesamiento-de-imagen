const fileInput = document.getElementById("fileInput");

const canvasOriginal = document.getElementById("original");
const canvasRed = document.getElementById("red");
const canvasBlue = document.getElementById("blue");
const canvasGreen = document.getElementById("green");
const canvasY = document.getElementById("y");
const canvasCb = document.getElementById("cb");
const canvasCr = document.getElementById("cr");

const ctxOriginal = canvasOriginal.getContext("2d");
const ctxRed = canvasRed.getContext("2d");
const ctxBlue = canvasBlue.getContext("2d");
const ctxGreen = canvasGreen.getContext("2d");
const ctxY = canvasY.getContext("2d");
const ctxCb = canvasCb.getContext("2d");
const ctxCr = canvasCr.getContext("2d");

const MAX_WIDTH = 600;
const MAX_HEIGHT = 400;

fileInput.addEventListener("change", function () {

    const file = fileInput.files[0];

    if (!file) {
        return;
    }

    const image = new Image();

    image.onload = function () {


        let width = image.width;
        let height = image.height;

        const scale = Math.min(
            MAX_WIDTH / width,
            MAX_HEIGHT / height,
            1
        );

        width = Math.floor(width * scale);
        height = Math.floor(height * scale);



        const tempCanvas = document.createElement("canvas");

        tempCanvas.width = width;
        tempCanvas.height = height;

        const tempCtx = tempCanvas.getContext("2d");

        tempCtx.drawImage(
            image,
            0,
            0,
            width,
            height
        );



        canvasOriginal.width = width;
        canvasOriginal.height = height;

        canvasRed.width = width;
        canvasRed.height = height;

        canvasBlue.width = width;
        canvasBlue.height = height;
        
        canvasGreen.width = width;
        canvasGreen.height = height;
        
        canvasY.width = width;
        canvasY.height = height;
        
        canvasCb.width = width;
        canvasCb.height = height;

        canvasCr.width = width;
        canvasCr.height = height;


        ctxOriginal.drawImage(
            tempCanvas,
            0,
            0
        );



        const imageData = tempCtx.getImageData(
            0,
            0,
            width,
            height
        );

        const data = imageData.data;

        const redData = ctxRed.createImageData(
            width,
            height
        );

        const blueData = ctxBlue.createImageData(
            width,
            height
        );

        const greenData = ctxGreen.createImageData(
            width,
            height
        );

        
        const yData = ctxY.createImageData(
            width,
            height
        );
        
        const cbData = ctxCb.createImageData(
            width,
            height
        );
        
        const crData = ctxCr.createImageData(
            width,
            height
        );
    


        for (let y = 0; y < height; y++) {

            for (let x = 0; x < width; x++) {

                const index = (y * width + x) * 4;

                // Obtener RGB
                const R = data[index];
                const G = data[index + 1];
                const B = data[index + 2];

                // Canal rojo
                redData.data[index] = R;
                redData.data[index + 1] = 0;
                redData.data[index + 2] = 0;
                redData.data[index + 3] = 255;


                // Obtener RGB
                const RB = data[index];
                const GB = data[index + 1];
                const BB = data[index + 2];

                // Canal azul
                blueData.data[index] = 0;
                blueData.data[index + 1] = 0;
                blueData.data[index + 2] = B;
                blueData.data[index + 3] = 255;

                
                // Obtener RGB
                const RG = data[index];
                const GG = data[index + 1];
                const BG = data[index + 2];

                // Canal verde
                greenData.data[index] = 0;
                greenData.data[index + 1] = G;
                greenData.data[index + 2] = 0;
                greenData.data[index + 3] = 255;

                        
                const a = 0.299;
                const b = 0.587;
                const c = 0.114;
                const d = 1.772;
                const e = 1.402;


                const Y = a*R+b*G+c*B
                const Cb = (B-Y) /d + 128;
                const Cr = (R-Y)/e+128;

                //y
                yData.data[index] = Y;
                yData.data[index + 1] = Y;
                yData.data[index + 2] = Y;
                yData.data[index + 3] = 255;

                //Cb
                cbData.data[index] = Cb;
                cbData.data[index + 1] = Cb;
                cbData.data[index + 2] = Cb;
                cbData.data[index + 3] = 255;

                
                //Cr
                crData.data[index] = Cr;
                crData.data[index + 1] = Cr;
                crData.data[index + 2] = Cr;
                crData.data[index + 3] = 255;
            }
        }

        ctxRed.putImageData(
            redData,
            0,
            0
        );
        ctxBlue.putImageData(
            blueData,
            0,
            0
        );
        ctxGreen.putImageData(
            greenData,
            0,
            0
        );
        
        ctxY.putImageData(
            yData,
            0,
            0
        );
        
        ctxCb.putImageData(
            cbData,
            0,
            0
        );
        
        ctxCr.putImageData(
            crData,
            0,
            0
        );
        

    };

    image.src = URL.createObjectURL(file);
});