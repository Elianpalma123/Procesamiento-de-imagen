const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

let tx = 0;
let ty = 0;
let angle = 0;
let sx = 1;
let sy = 1;

// Centro de la nave
const cx = 250;
const cy = 280;

const increment = 10;
const aIncrement = Math.PI / 18;
const sIncrement = 0.1;

const partesUfo = [
    // Cúpula
    {
        puntos: [
            { x: 200, y: 220, z: 1 }, { x: 215, y: 175, z: 1 },
            { x: 250, y: 155, z: 1 }, { x: 285, y: 175, z: 1 },
            { x: 300, y: 220, z: 1 }
        ]
    },
    // Cuerpo
    {
        puntos: [
            { x: 200, y: 220, z: 1 }, { x: 130, y: 245, z: 1 },
            { x: 250, y: 280, z: 1 }, { x: 370, y: 245, z: 1 },
            { x: 300, y: 220, z: 1 }
        ]
    },
    // Luz 1
    {
        puntos: [
            { x: 170, y: 248, z: 1 }, { x: 180, y: 258, z: 1 },
            { x: 190, y: 248, z: 1 }, { x: 180, y: 242, z: 1 }
        ]
    },
    // Luz 2
    {
        puntos: [
            { x: 240, y: 258, z: 1 }, { x: 250, y: 270, z: 1 },
            { x: 260, y: 258, z: 1 }, { x: 250, y: 250, z: 1 }
        ]
    },
    // Luz 3
    {
        puntos: [
            { x: 310, y: 248, z: 1 }, { x: 320, y: 258, z: 1 },
            { x: 330, y: 248, z: 1 }, { x: 320, y: 242, z: 1 }
        ]
    },
    // Rayo Láser
    {
        puntos: [
            { x: 210, y: 268, z: 1 }, { x: 150, y: 400, z: 1 },
            { x: 350, y: 400, z: 1 }, { x: 290, y: 268, z: 1 }
        ]
    }
];
document.addEventListener("keydown", function (event) {
   
    if (event.key === "d" ) tx += increment;
    if (event.key === "a" ) tx -= increment;
    if (event.key === "w" ) ty -= increment;
    if (event.key === "s" ) ty += increment;

    if (event.key === "e" ) { sx += sIncrement; sy += sIncrement; }
    if (event.key === "r"   ) { sx -= sIncrement; sy -= sIncrement; }

    if (event.key === "t" ) angle += aIncrement;
    if (event.key === "y" ) angle -= aIncrement;

    tranformar();
});

function tranformar() {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);

    const M = [
        [sx * cos, -sx * sin, tx + cx - (sx * cos * cx - sx * sin * cy)],
        [sy * sin,  sy * cos, ty + cy - (sy * sin * cx + sy * cos * cy)],
        [0, 0, 1]
    ];

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let p = 0; p < partesUfo.length; p++) {
        const parte = partesUfo[p];
        const piezaTrans = [];

        for (let i = 0; i < parte.puntos.length; i++) {
            const punto = parte.puntos[i];
            const P = [[punto.x], [punto.y], [punto.z]];

            const x = M[0][0] * P[0][0] + M[0][1] * P[1][0] + M[0][2] * P[2][0];
            const y = M[1][0] * P[0][0] + M[1][1] * P[1][0] + M[1][2] * P[2][0];
            const z = M[2][0] * P[0][0] + M[2][1] * P[1][0] + M[2][2] * P[2][0];

            piezaTrans.push({ x: x, y: y, z: z });
        }

        ctx.strokeStyle = "red";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(piezaTrans[0].x, piezaTrans[0].y);
        for (let i = 1; i < piezaTrans.length; i++) {
            ctx.lineTo(piezaTrans[i].x, piezaTrans[i].y);
        }
        ctx.closePath();
        ctx.stroke();

        ctx.fillStyle = "white";
        for (let i = 0; i < piezaTrans.length; i++) {
            ctx.beginPath();
            ctx.arc(piezaTrans[i].x, piezaTrans[i].y, 5, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}

tranformar();
