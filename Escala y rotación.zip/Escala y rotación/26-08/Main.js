
// CANVAS

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");




// Traslación


let tx = 0;
let ty = 0;

const increment = 10;

let sx = 1;
let sy = 1;
const scale = 0.1;

let angle = 0;

let rx = Math.cos(angle);
let ry = Math.sin(angle);



// Figura original (un cuadrado)


const figure = [

    { x: 300, y: 200, z: 1 },

    { x: 400, y: 200, z: 1 },

    { x: 400, y: 300, z: 1 },

    { x: 300, y: 300, z: 1 }

];



// Figura transformada (inicialmente igual a la original)


let figureTra = [];
let figureSca = [];
let figureRot = [];



// Teclas para mover la figura: W (arriba), A (izquierda), S (abajo), D (derecha)


document.addEventListener("keydown", function(event) {

    if (event.key === "d") {
        tx += increment;
    }

    if (event.key === "a") {
        tx -= increment;
    }

    if (event.key === "w") {
        ty -= increment;
    }

    if (event.key === "s") {
        ty += increment;
    }

    
    MatrizTraslacion();

    if (event.key === "e") {
        sy += scale;
        sx += scale;
        MatrizEscala();
    }
    
    if (event.key === "r") {
        sy -= scale;
        sx -= scale;
        MatrizEscala();
    }

    if (event.key === "t") {
        angle += Math.PI / 18;
        rx = Math.cos(angle);
        ry = Math.sin(angle);
        MatrizRotacion();
    }

    if (event.key === "y") {
        angle -= Math.PI / 18;
        rx = Math.cos(angle);
        ry = Math.sin(angle);
        MatrizRotacion();
    }
   

});



// Transformar la figura según la matriz de traslación


function MatrizTraslacion() {

    // Matriz de traslación 3x3

    const T = [

        [1, 0, tx],

        [0, 1, ty],

        [0, 0, 1]

    ];

    // Vaciar la figura transformada antes de recalcularla
    figureTra = [];

    // Trasformar la figura

   for (let i = 0; i < figure.length; i++) {

        const punto = figure[i];

        const P = [
            [punto.x],
            [punto.y],
            [punto.z]
        ];

        const x =T[0][0] * P[0][0] +T[0][1] * P[1][0] + T[0][2] * P[2][0];
        const y =T[1][0] * P[0][0] + T[1][1] * P[1][0] + T[1][2] * P[2][0];
        const z =T[2][0] * P[0][0] + T[2][1] * P[1][0] + T[2][2] * P[2][0];

        figureTra[i] = {
            x: x,
            y: y,
            z: z
        };

    }


    // Dibujar canvas

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

   


  
    // Figura transformada (con líneas)


   ctx.strokeStyle = "red";

    ctx.beginPath();

    ctx.moveTo(figureTra[0].x,figureTra[0].y);

    for ( let i = 1;i < figureTra.length; i++) {

        ctx.lineTo(figureTra[i].x,figureTra[i].y);
        ctx.lineWidth = 3;
    }

    ctx.closePath();

    ctx.stroke();

 // Dibujar puntos de la figura transformada

    ctx.fillStyle = "white";

    for ( let i = 0;i < figureTra.length; i++) {

        ctx.beginPath();

        ctx.arc(
            figureTra[i].x,
            figureTra[i].y,
            6,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }


}

MatrizTraslacion();
//-----

function MatrizEscala() {

    // Matriz de traslación 3x3

    const T = [

        [sx, 0, 0],

        [0, sy, 0],

        [0, 0, 1]

    ];

    // Vaciar la figura transformada antes de recalcularla
    figureSca = [];

    // Trasformar la figura

   for (let i = 0; i < figure.length; i++) {

        const punto = figure[i];

        const P = [
            [punto.x],
            [punto.y],
            [punto.z]
        ];

        const x =T[0][0] * P[0][0] +T[0][1] * P[1][0] + T[0][2] * P[2][0];
        const y =T[1][0] * P[0][0] + T[1][1] * P[1][0] + T[1][2] * P[2][0];
        const z =T[2][0] * P[0][0] + T[2][1] * P[1][0] + T[2][2] * P[2][0];

        figureSca[i] = {
            x: x,
            y: y,
            z: z
        };

    }


    // Dibujar canvas

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

   


  
    // Figura transformada (con líneas)


   ctx.strokeStyle = "red";

    ctx.beginPath();

    ctx.moveTo(figureSca[0].x,figureSca[0].y);

    for ( let i = 1;i < figureSca.length; i++) {

        ctx.lineTo(figureSca[i].x,figureSca[i].y);
        ctx.lineWidth = 3;
    }

    ctx.closePath();

    ctx.stroke();

 // Dibujar puntos de la figura transformada

    ctx.fillStyle = "white";

    for ( let i = 0;i < figureSca.length; i++) {

        ctx.beginPath();

        ctx.arc(
            figureSca[i].x,
            figureSca[i].y,
            6,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }


}



// dibujar la figura
 
MatrizEscala();


function MatrizRotacion() {

    // Matriz de traslación 3x3

    const T = [
        [rx, -ry, 0],
        [ry, rx, 0],
        [0, 0, 1]

    ];

    // Vaciar la figura transformada antes de recalcularla
    figureRot= [];

    // Trasformar la figura

   for (let i = 0; i < figure.length; i++) {

        const punto = figure[i];

        const P = [
            [punto.x],
            [punto.y],
            [punto.z]
        ];

        const x =T[0][0] * P[0][0] +T[0][1] * P[1][0] + T[0][2] * P[2][0];
        const y =T[1][0] * P[0][0] + T[1][1] * P[1][0] + T[1][2] * P[2][0];
        const z =T[2][0] * P[0][0] + T[2][1] * P[1][0] + T[2][2] * P[2][0];

        figureRot[i] = {
            x: x,
            y: y,
            z: z
        };

    }


    // Dibujar canvas

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

   


  
    // Figura transformada (con líneas)


   ctx.strokeStyle = "red";

    ctx.beginPath();

    ctx.moveTo(figureRot[0].x,figureRot[0].y);

    for ( let i = 1;i < figureRot.length; i++) {

        ctx.lineTo(figureRot[i].x,figureRot[i].y);
        ctx.lineWidth = 3;
    }

    ctx.closePath();

    ctx.stroke();

 // Dibujar puntos de la figura transformada

    ctx.fillStyle = "white";

    for ( let i = 0;i < figureRot.length; i++) {

        ctx.beginPath();

        ctx.arc(
            figureRot[i].x,
            figureRot[i].y,
            6,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }


}

MatrizRotacion();
