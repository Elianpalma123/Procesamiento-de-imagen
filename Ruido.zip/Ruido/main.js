const fileInput = document.getElementById("fileInput");
const botonRuido = document.getElementById("aplicarRuido");
const botonK1 = document.getElementById("botonK1");
const botonK2 = document.getElementById("botonK2");
const botonMediana = document.getElementById("botonMediana");

const canvasOriginal = document.getElementById("original");
const ctxOriginal = canvasOriginal.getContext("2d");

const canvasRuido = document.getElementById("ruido");
const ctxRuido = canvasRuido.getContext("2d");

const canvasKernel = document.getElementById("kernel");
const ctxKernel = canvasKernel.getContext("2d");

const MAX_WIDTH = 600;
const MAX_HEIGHT = 400;

let imagen = new Image();

const kernels = {
    promedio: {
        matriz: [
            [1, 1, 1],
            [1, 1, 1],
            [1, 1, 1]
        ],
        divisor: 9
    },
    Kernel: {
        matriz: [
            [1, 2, 1],
            [2, 4, 2],
            [1, 2, 1]
        ],
        divisor: 16
    }
};

fileInput.addEventListener("change", function() {

    const file = fileInput.files[0];

    if (!file) {
        return;
    }

    imagen.src = URL.createObjectURL(file);
});

imagen.onload = function() {

    let ancho = imagen.width;
    let alto = imagen.height;

    const escalaX = MAX_WIDTH / ancho;
    const escalaY = MAX_HEIGHT / alto;

    const escala = Math.min(escalaX, escalaY, 1);

    ancho = Math.floor(ancho * escala);
    alto = Math.floor(alto * escala);

    canvasOriginal.width = ancho;
    canvasOriginal.height = alto;

    canvasRuido.width = ancho;
    canvasRuido.height = alto

    canvasKernel.width = ancho;
    canvasKernel.height = alto;

    ctxOriginal.drawImage(imagen, 0, 0, ancho, alto);
    ctxRuido.drawImage(imagen, 0, 0, ancho, alto);
    ctxKernel.drawImage(imagen, 0, 0, ancho, alto);
};

botonRuido.addEventListener("click", function() {

    const ancho = canvasRuido.width;
    const alto = canvasRuido.height;

    const imageData = ctxRuido.getImageData(0, 0, ancho, alto);
    const datos = imageData.data;

    for (let y = 0; y < alto; y++) {

        for (let x = 0; x < ancho; x++) {

            const i = (y * ancho + x) * 4;

            if (Math.random() < 0.05) {

                if (Math.random() < 0.5) {

                    datos[i] = 255;
                    datos[i + 1] = 255;
                    datos[i + 2] = 255;

                } else {

                    datos[i] = 0;
                    datos[i + 1] = 0;
                    datos[i + 2] = 0;
                }
            }
        }
    }

    ctxRuido.putImageData(imageData, 0, 0);
});

botonK1.addEventListener("click", function() {
    aplicarConvolucion(kernels.promedio);
});

botonK2.addEventListener("click", function() {
    aplicarConvolucion(kernels.Kernel);
});

botonMediana.addEventListener("click", function() {
    aplicarMediana();
});


function clamp(valor) {
    return Math.max(0, Math.min(255, Math.round(valor)));
}

function aplicarConvolucion(kernel) {
    const ancho = canvasRuido.width;
    const alto = canvasRuido.height;
    const entrada = ctxRuido.getImageData(0, 0, ancho, alto);
    const datosEntrada = entrada.data;

    const salida = ctxKernel.createImageData(ancho, alto);
    const datosSalida = salida.data;

    const matriz = kernel.matriz;
    const divisor = kernel.divisor;
    const radio = Math.floor(matriz.length / 2);

    for (let y = 0; y < alto; y++) {
        for (let x = 0; x < ancho; x++) {
            let sumR = 0;
            let sumG = 0;
            let sumB = 0;

            for (let ky = -radio; ky <= radio; ky++) {
                for (let kx = -radio; kx <= radio; kx++) {
                    const pixelX = x + kx;
                    const pixelY = y + ky;

                    if (pixelX < 0 || pixelX >= ancho || pixelY < 0 || pixelY >= alto) {
                        continue;
                    }

                    const kVal = matriz[ky + radio][kx + radio];
                    const i = (pixelY * ancho + pixelX) * 4;

                    sumR += datosEntrada[i] * kVal;
                    sumG += datosEntrada[i + 1] * kVal;
                    sumB += datosEntrada[i + 2] * kVal;
                }
            }

            const iSalida = (y * ancho + x) * 4;
            datosSalida[iSalida] = clamp(sumR / divisor);
            datosSalida[iSalida + 1] = clamp(sumG / divisor);
            datosSalida[iSalida + 2] = clamp(sumB / divisor);
            datosSalida[iSalida + 3] = 255;
        }
    }

    ctxKernel.putImageData(salida, 0, 0);
}

function aplicarMediana() {
    const ancho = canvasRuido.width;
    const alto = canvasRuido.height;

    const entrada = ctxRuido.getImageData(0, 0, ancho, alto);
    const datosEntrada = entrada.data;

    const salida = ctxKernel.createImageData(ancho, alto);
    const datosSalida = salida.data;

    for (let y = 0; y < alto; y++) {
        for (let x = 0; x < ancho; x++) {
            const iSalida = (y * ancho + x) * 4;

            const R = datosEntrada[iSalida];
            const G = datosEntrada[iSalida + 1];
            const B = datosEntrada[iSalida + 2];

            const esRuidoNegro = (R < 60 && G < 60 && B < 60);
            const esRuidoBlanco = (R > 195 && G > 195 && B > 195);

            if (!esRuidoNegro && !esRuidoBlanco) {
                datosSalida[iSalida] = R;
                datosSalida[iSalida + 1] = G;
                datosSalida[iSalida + 2] = B;
                datosSalida[iSalida + 3] = 255;
                continue;
            }

            let listaR = [];
            let listaG = [];
            let listaB = [];

            for (let ky = -1; ky <= 1; ky++) {
                for (let kx = -1; kx <= 1; kx++) {
                    const pixelX = x + kx;
                    const pixelY = y + ky;

                    if (pixelX < 0 || pixelX >= ancho || pixelY < 0 || pixelY >= alto) {
                        continue;
                    }

                    const i = (pixelY * ancho + pixelX) * 4;

                    listaR.push(datosEntrada[i]);
                    listaG.push(datosEntrada[i + 1]);
                    listaB.push(datosEntrada[i + 2]);
                }
            }

            listaR.sort((a, b) => a - b);
            listaG.sort((a, b) => a - b);
            listaB.sort((a, b) => a - b);

            const mitad = Math.floor(listaR.length / 2);

            datosSalida[iSalida] = listaR[mitad];
            datosSalida[iSalida + 1] = listaG[mitad];
            datosSalida[iSalida + 2] = listaB[mitad];
            datosSalida[iSalida + 3] = 255;
        }
    }

    ctxKernel.putImageData(salida, 0, 0);
}





