
    // Canvas y contextos
   

    const canvasOriginal =document.getElementById("canvasOriginal");
    const ctxOriginal = canvasOriginal.getContext("2d");


    const canvasRojo = document.getElementById("histogramaRojo");
    const ctxRojo = canvasRojo.getContext("2d");

    const canvasVerde = document.getElementById("histogramaVerde");
    const ctxVerde = canvasVerde.getContext("2d");

    
    const canvasAzul = document.getElementById("histogramaAzul");
    const ctxAzul = canvasAzul.getContext("2d");
    
    const canvasLuminancia = document.getElementById("histogramaLuminancia");
    const ctxLuminancia = canvasLuminancia.getContext("2d");


    const archivo = document.getElementById("archivo");


  
    // Histograma
  

    let histR = new Array(256).fill(0);
    let histV = new Array(256).fill(0);
    let histB = new Array(256).fill(0);
    let histL = new Array(256).fill(0);


 
    // Cargar imagen y calcular histograma


    archivo.addEventListener("change", function(event) {

        const file = event.target.files[0];

        if (!file) {
            return;
        }


        const imagen = new Image();


        imagen.onload = function() {

            // Redimensionar imagen si es necesario


            let ancho = imagen.width;
            let alto = imagen.height;


            const maxAncho = 600;
            const maxAlto = 400;


            const escala = Math.min( maxAncho / ancho, maxAlto / alto, 1 );


            ancho = Math.floor(ancho * escala);
            alto = Math.floor(alto * escala);


            canvasOriginal.width = ancho;
            canvasOriginal.height = alto;

            // Dibujar imagen en el canvas original


            ctxOriginal.clearRect(0, 0, ancho, alto );
            ctxOriginal.drawImage(imagen, 0,0, ancho, alto );



            // Calcular histograma del canal rojo

            calcularHistogramaRojo();
            // Dibujar histograma del canal rojo
            dibujarHistogramaRojo();
            dibujarHistogramaVerde();
            
            dibujarHistogramaAzul();
            
            dibujarHistogramaLuminancia();

        };


        imagen.src = URL.createObjectURL(file);

    });



    // Calcvular histograma del canal rojo
    function calcularHistogramaRojo() {

        // Reiniciar histograma

        histR = new Array(256).fill(0);
        histV = new Array(256).fill(0);
        histB = new Array(256).fill(0);
        
        histL = new Array(256).fill(0);
        const ancho = canvasOriginal.width;
        const alto = canvasOriginal.height;


        // Obtener los píxeles

        const datos = ctxOriginal.getImageData( 0, 0,ancho, alto ).data;

        // Recorrer los píxeles y contar la frecuencia de cada valor del canal rojo
        for ( let i = 0; i < datos.length; i += 4 ) {

            // Canal rojo

            const r = datos[i];
            const g = datos[i+1];
            const b = datos[i+2];

            const l = Math.round(0.299*r+0.587*g+0.114*b);
            // Aumentar frecuencia del valor del canal rojo 
            

            histR[r]++;
            histV[g]++;
            histB[b]++;
            
            histL[l]++;

        }

    }


  
    // Dibujar histograma del canal rojo


    function dibujarHistogramaRojo() {

        const ancho = canvasRojo.width;
        const alto = canvasRojo.height;



        // Limpiar canvas 


        ctxRojo.clearRect( 0, 0, ancho, alto);
      
        // Fondo blanco para el histograma


        ctxRojo.fillStyle = "white";
        ctxRojo.fillRect( 0, 0, ancho, alto );

        // Valor máximo del histograma para escalar las barras

        const maximo = Math.max(...histR);



        // Ejes X e Y


        ctxRojo.strokeStyle = "black";
        ctxRojo.beginPath();


        // Eje Y

        ctxRojo.moveTo( 40, alto - 40);
        ctxRojo.lineTo( 40,alto - 40);


        // Eje X

        ctxRojo.lineTo( ancho - 10, alto - 40);
        ctxRojo.stroke();


        // Escalas x 
  

        const escalaX =(ancho - 50) / 256;

        // Barras del histograma del canal rojo
      
        ctxRojo.fillStyle = "rgba(255, 0, 0, 0.6)";
        for ( let i = 0; i < 256; i++) {

          // Posición x de la barra 
            const x =  40 + i * escalaX;

          // Altura de la barra proporcional a la frecuencia del valor del canal rojo
            const altura =(histR[i] / maximo) *(alto - 60);

          // Dibujar la barra del histograma
            ctxRojo.fillRect(x,alto - 40 - altura, Math.max(1, escalaX), altura);

        }


        // Valores del eje X 
        ctxRojo.fillStyle = "black";

        ctxRojo.font = "11px Arial";


        const valores = [

            0,
            32,
            64,
            96,
            128,
            160,
            192,
            224,
            255

        ];

        // Dibujar los valores del eje X

        for ( const valor of valores) {
            // Posición x
            const x = 40 + valor * escalaX;

          // Dibujar línea de referencia en el eje X
            ctxRojo.fillText( valor,x - 8, alto - 20);

        }


        // Texto del eje X 


        ctxRojo.fillText("Intensidad del rojo", ancho / 2 - 50,alto - 5);

        // Texto del eje Y

        ctxRojo.save();
        ctxRojo.translate(12,alto / 2);
        ctxRojo.rotate( -Math.PI / 2 );
        ctxRojo.fillText( "Frecuencia", 0, 0);
        ctxRojo.restore();

    }

    /////VERDEEEE

    function dibujarHistogramaVerde() {

        const ancho = canvasVerde.width;
        const alto = canvasVerde.height;



        // Limpiar canvas 


        ctxVerde.clearRect( 0, 0, ancho, alto);
      
        // Fondo blanco para el histograma


        ctxVerde.fillStyle = "white";
        ctxVerde.fillRect( 0, 0, ancho, alto );

        // Valor máximo del histograma para escalar las barras

        const maximo = Math.max(...histV);



        // Ejes X e Y


        ctxVerde.strokeStyle = "black";
        ctxVerde.beginPath();


        // Eje Y

        ctxVerde.moveTo( 40, alto - 40);
        ctxVerde.lineTo( 40,alto - 40);


        // Eje X

        ctxVerde.lineTo( ancho - 10, alto - 40);
        ctxVerde.stroke();


        // Escalas x 
  

        const escalaX =(ancho - 50) / 256;

        // Barras del histograma del canal rojo
      
        ctxVerde.fillStyle = "rgba(0, 255, 0, 0.6)";
        for ( let i = 0; i < 256; i++) {

          // Posición x de la barra 
            const x =  40 + i * escalaX;

          // Altura de la barra proporcional a la frecuencia del valor del canal rojo
            const altura =(histV[i] / maximo) *(alto - 60);

          // Dibujar la barra del histograma
            ctxVerde.fillRect(x,alto - 40 - altura, Math.max(1, escalaX), altura);

        }


        // Valores del eje X 
        ctxVerde.fillStyle = "black";

        ctxVerde.font = "11px Arial";


        const valores = [

            0,
            32,
            64,
            96,
            128,
            160,
            192,
            224,
            255

        ];

        // Dibujar los valores del eje X

        for ( const valor of valores) {
            // Posición x
            const x = 40 + valor * escalaX;

          // Dibujar línea de referencia en el eje X
            ctxVerde.fillText( valor,x - 8, alto - 20);

        }


        // Texto del eje X 


        ctxVerde.fillText("Intensidad del verde", ancho / 2 - 50,alto - 5);

        // Texto del eje Y

        ctxVerde.save();
        ctxVerde.translate(12,alto / 2);
        ctxVerde.rotate( -Math.PI / 2 );
        ctxVerde.fillText( "Frecuencia", 0, 0);
        ctxVerde.restore();

    }

    function dibujarHistogramaAzul() {

        const ancho = canvasAzul.width;
        const alto = canvasAzul.height;



        // Limpiar canvas 


        ctxAzul.clearRect( 0, 0, ancho, alto);
      
        // Fondo blanco para el histograma


        ctxAzul.fillStyle = "white";
        ctxAzul.fillRect( 0, 0, ancho, alto );

        // Valor máximo del histograma para escalar las barras

        const maximo = Math.max(...histB);



        // Ejes X e Y


        ctxAzul.strokeStyle = "black";
        ctxAzul.beginPath();


        // Eje Y

        ctxAzul.moveTo( 40, alto - 40);
        ctxAzul.lineTo( 40,alto - 40);


        // Eje X

        ctxAzul.lineTo( ancho - 10, alto - 40);
        ctxAzul.stroke();


        // Escalas x 
  

        const escalaX =(ancho - 50) / 256;

        // Barras del histograma del canal rojo
      
        ctxAzul.fillStyle = "rgba(0, 0, 255, 0.6)";
        for ( let i = 0; i < 256; i++) {

          // Posición x de la barra 
            const x =  40 + i * escalaX;

          // Altura de la barra proporcional a la frecuencia del valor del canal rojo
            const altura =(histB[i] / maximo) *(alto - 60);

          // Dibujar la barra del histograma
            ctxAzul.fillRect(x,alto - 40 - altura, Math.max(1, escalaX), altura);

        }


        // Valores del eje X 
        ctxAzul.fillStyle = "black";

        ctxAzul.font = "11px Arial";


        const valores = [

            0,
            32,
            64,
            96,
            128,
            160,
            192,
            224,
            255

        ];

        // Dibujar los valores del eje X

        for ( const valor of valores) {
            // Posición x
            const x = 40 + valor * escalaX;

          // Dibujar línea de referencia en el eje X
            ctxAzul.fillText( valor,x - 8, alto - 20);

        }


        // Texto del eje X 


        ctxAzul.fillText("Intensidad del azul", ancho / 2 - 50,alto - 5);

        // Texto del eje Y

        ctxAzul.save();
        ctxAzul.translate(12,alto / 2);
        ctxAzul.rotate( -Math.PI / 2 );
        ctxAzul.fillText( "Frecuencia", 0, 0);
        ctxAzul.restore();

    }


    //// luminanciiaaaaaa

    function dibujarHistogramaLuminancia() {

        const ancho = canvasRojo.width;
        const alto = canvasRojo.height;



        // Limpiar canvas 


        ctxLuminancia.clearRect( 0, 0, ancho, alto);
      
        // Fondo blanco para el histograma


        ctxLuminancia.fillStyle = "white";
        ctxLuminancia.fillRect( 0, 0, ancho, alto );

        // Valor máximo del histograma para escalar las barras

        const maximo = Math.max(...histL);



        // Ejes X e Y


        ctxLuminancia.strokeStyle = "black";
        ctxLuminancia.beginPath();


        // Eje Y

        ctxLuminancia.moveTo( 40, alto - 40);
        ctxLuminancia.lineTo( 40,alto - 40);


        // Eje X

        ctxLuminancia.lineTo( ancho - 10, alto - 40);
        ctxLuminancia.stroke();


        // Escalas x 
  

        const escalaX =(ancho - 50) / 256;

        // Barras del histograma del canal rojo
      
        ctxLuminancia.fillStyle = "rgba(43, 43, 43, 0.6)";
        for ( let i = 0; i < 256; i++) {

          // Posición x de la barra 
            const x =  40 + i * escalaX;

          // Altura de la barra proporcional a la frecuencia del valor del canal rojo
            const altura =(histL[i] / maximo) *(alto - 60);

          // Dibujar la barra del histograma
            ctxLuminancia.fillRect(x,alto - 40 - altura, Math.max(1, escalaX), altura);

        }


        // Valores del eje X 
        ctxLuminancia.fillStyle = "black";

        ctxLuminancia.font = "11px Arial";


        const valores = [

            0,
            32,
            64,
            96,
            128,
            160,
            192,
            224,
            255

        ];

        // Dibujar los valores del eje X

        for ( const valor of valores) {
            // Posición x
            const x = 40 + valor * escalaX;

          // Dibujar línea de referencia en el eje X
            ctxLuminancia.fillText( valor,x - 8, alto - 20);

        }


        // Texto del eje X 


        ctxLuminancia.fillText("Intensidad del luminancia", ancho / 2 - 50,alto - 5);

        // Texto del eje Y

        ctxLuminancia.save();
        ctxLuminancia.translate(12,alto / 2);
        ctxLuminancia.rotate( -Math.PI / 2 );
        ctxLuminancia.fillText( "Frecuencia", 0, 0);
        ctxLuminancia.restore();

    }